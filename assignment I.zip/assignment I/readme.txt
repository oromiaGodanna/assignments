
Assignment I

Dictionary done with android 

Implementation methodology

This android app has two parts. the first one is 
done with mvc design pattern holding the view the controller and the 
database and allows users to add words, and the other part allows users 
to search words from the database which means it uses the client server 
architectural design pattern as well.

Implemented functionality

implemented functionalities are adding words to a database and retrieving 
words from the database.