package com.example.ori.myapplication;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText searchWord;
    Button searchBtn;
    TextView detail;
    EditText editText2;
    EditText editText3;
    Button button1;
    TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final searchDb database = new searchDb(this);


        searchWord = (EditText) findViewById(R.id.searchWord);
        final String wordInputSearch = searchWord.getText().toString();
        detail = (TextView) findViewById(R.id.detail);

        searchBtn = (Button) findViewById(R.id.searchBtn);
        searchBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
               Cursor data =  database.getWord(searchWord.getText().toString());

               String meaning = data.toString();
//                String  all = wordInputSearch.concat(": ").concat(meaning);
                detail.setText(searchWord.getText().toString().concat(": ").concat(meaning));
            }
        });

        editText2 = (EditText) findViewById(R.id.editText);
        editText3 = (EditText) findViewById(R.id.editText3);



        button1 = (Button) findViewById(R.id.button2);
        button1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editText3.getText().toString().equals("") & editText2.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "Word or Definition can not be empty.", Toast.LENGTH_SHORT).show();

                }
                else {
                    database.addWord(editText2.getText().toString(), editText3.getText().toString());
                    Toast.makeText(MainActivity.this, "successfully added.!.", Toast.LENGTH_SHORT).show();

                }

            }
        });



    }
}
