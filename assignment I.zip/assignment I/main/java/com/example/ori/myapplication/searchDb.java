package com.example.ori.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteOpenHelper;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.security.PublicKey;

import static android.R.attr.name;

public class searchDb extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="wordsDB";
    public searchDb(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE words (word TEXT, definition TEXT);");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS words");
        onCreate(db);
    }

    public void addWord(String word,String definition)
    {

        ContentValues values=new ContentValues(2);
        values.put("word", word);
        values.put("definition", definition);
        getWritableDatabase().insert("words", "word", values);
    }
    public Cursor getWord(String sWord){
       Cursor cursor = getReadableDatabase().rawQuery("SELECT definition from words WHERE word ="+ sWord, null);

        return cursor;

    }
}
